<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Traits\JsonResponse;

class ApiController extends Controller
{
    use JsonResponse;
}
